const axios = require('axios')
const connection = require('../model/database');
const { end } = require('../model/database');
const router = require('express').Router()
const bodyParser = require('body-parser');
module.exports = router

const key = "AIzaSyA7nfzqox7HP_crX14tFzVLVpW3r5PnHoI";
router.put("/status", bodyParser.json(), function (req, res) {
    try {
        var id = req.body.delvary_id
        var online = req.body.status
        var type = req.body.type
        var location = req.body.location
        var sql = "UPDATE `captain` set `online_status`='" + online + "',`translation_status`= '" +
            type + "',`location`= '" + location + "' where `delvary_id`=?";
        connection.query(sql, id, function (err, result) {
            if (err) throw err
            res.status(200).json({
                record: "status updeted"
            })
        })
    }
    catch (err) {
        console.log(err)
        next(err)
    }

})
router.post("/rate", bodyParser.json(), function (req, res) {
    try {
        var id = req.body.delvary_id
        var rate = req.body.rate

        var sql = "INSERT INTO `rate`(`captain_id`, `rate`) VALUES('" + id + "' ,'" + rate + "');"
        connection.query(sql, id, function (err, result) {
            if (err) throw err
            res.status(200).json({
                record: "rated"
            })
        })
    }
    catch (err) {
        console.log(err)
        next(err)
    }

})

function distance_api(user_location, key, captains_location) {
    var s = `https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=`
    var e = `&destinations=${user_location}&key=${key}`
    for (var i = 0; i < captains_location.length; i++) {
        if (i == captains_location.length - 1)
            s = s.concat(captains_location[i])
        else
            s = s.concat(captains_location[i] + '|')

    }
    var user_location = s.concat(e);
    return user_location
}
function convert(data) {
    var distance
    var temp = 0, x;
    temp = data.rows[0].elements[0].distance.text.split(' ')
    console.log(temp[0])
    if (temp[0, 1] == 'ft') {
        temp[0, 0] = (parseFloat(temp[0, 0]) / 5280).toFixed(5)
    }
    temp[0, 0] = temp[0, 0].toString()
    if (temp[0].indexOf(',') == 1) {
        temp = temp[0].split(',')
        x = temp[0] + temp[1]
        temp[0] = x
    }
    distance = parseFloat(temp[0])
    return distance
}
function get_index(data) {
    var distance = []
    var temp, index = 0, x;
    for (var i = 0; i < data.rows.length; i++) {

        temp = data.rows[i].elements[0].distance.text.split(' ')
        if (temp[i, 1] == 'ft') {
            temp[i, 0] = (parseFloat(temp[i, 0]) / 5280).toFixed(5)
        }
        temp[i, 0] = temp[i, 0].toString()
        if (temp[0].indexOf(',') == 1) {
            temp = temp[0].split(',')
            x = temp[0] + temp[1]
            temp[0] = x
        }
        distance.push(parseFloat(temp[0]))
    }
    temp = distance[0]
    for (var i = 0; i < distance.length; i++) {
        if (distance[i] < temp) {
            temp = distance[i]
            index = i
        }
    }
    return index
}

router.post("/transportation", bodyParser.json(), async (req, res, next) => {
    try {
        var location = req.body.user_location
        var captains_location = []
        var rate = 0
        const key = "AIzaSyA7nfzqox7HP_crX14tFzVLVpW3r5PnHoI";
        var sql = "SELECT * FROM `captain` where `online_status`=1 and `translation_status`=1";
        connection.query(sql, async (err, result) => {
            if (err) throw err
            if (result.length > 0) {
                for (var i = 0; i < result.length; i++) {
                    captains_location.push(result[i].location)
                }
                const { data } = await axios.get(distance_api(location, key, captains_location))
                console.log(captains_location)
                console.log(result[get_index(data)].delvary_id)

                var sql = "SELECT * FROM `rate` where `captain_id`=?";
                connection.query(sql, result[get_index(data)].delvary_id, function (err, r) {
                    for (var i = 0; i < r.length; i++) {
                        rate = rate + r[i].rate
                    }
                    rate /= r.length
                    if (err) throw err
                    res.status(200).json({
                        "delvary_id": result[get_index(data)].delvary_id,
                        "frist_name": result[get_index(data)].First_name,
                        "last_name": result[get_index(data)].last_name,
                        "Scooter": result[get_index(data)].Scooter,
                        "location": result[get_index(data)].location,
                        "Email": result[get_index(data)].Email,
                        "distance": data.rows[get_index(data)].elements[0].distance.text,
                        "duration": data.rows[get_index(data)].elements[0].duration.text,
                        "rate": rate
                    })
                })
            }
            else {
                res.status(400).json({
                    record: "no captain active"
                })
            }
        })
    }
    catch (err) {
        console.log(err)
        next(err)
    }
})

router.post("/go_location", bodyParser.json(), async (req, res, next) => {
    try {
        var id = req.body.delvary_id
        var s_location = req.body.user_location
        var lat_s = req.body.lat_s
        var long_s = req.body.long_s
        var lat_e = req.body.lat_e
        var long_e = req.body.long_e
        var e_location = req.body.end_location
        var salary
        const key = "AIzaSyA7nfzqox7HP_crX14tFzVLVpW3r5PnHoI";
        const { data } = await axios.get(
            `https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=${s_location}&destinations=${e_location}&key=${key}`
        )
        salary = parseFloat(data.rows[0].elements[0].distance.text) * 6.5
        console.log(salary)
        var distance = data.rows[0].elements[0].distance.text
        var duration = data.rows[0].elements[0].duration.text
        var sql = "INSERT INTO `captain_trans`(`delevry`, `From_location`, `to_location`,`lat_s`, `long_s`,`lat_e`,`long_e`,`distance`, `duration`) VALUES ('"
            + id + "','" + s_location + "','" + e_location + "','" + lat_s + "','" + long_s + "','" +
            lat_e + "','" + long_e + "','" + distance + "','" + duration + "');"
        connection.query(sql, function (err, result) {
            if (err) throw err
            res.status(200).json({
                "distance": distance,
                "duration": duration,
                "salary": salary
            })
        })
    }
    catch (err) {
        next(err)
    }
})
async function distance(s_location, e_location, key) {
    const { data } = await axios.get(
        `https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=${s_location}&destinations=${e_location}&key=${key}`
    )
    var d = data.rows[0].elements[0].distance.text.split(' ')
    //console.log(distance[0, 1])
    if (d[0, 1] == 'ft') {
        d[0, 0] = (parseFloat(d[0, 0]) / 5280).toFixed(5)
    }
    d = parseFloat(d[0, 0])
    return d
}
async function duration(s_location, e_location, key) {
    const { data } = await axios.get(
        `https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=${s_location}&destinations=${e_location}&key=${key}`
    )
    var duration = data.rows[0].elements[0].duration.text.split(' ')
    if (duration.length > 2) {
        duration[0] = parseInt(duration[0]) * 60
        duration[2] = parseInt(duration[2])
        duration = duration[0] + duration[2]
    }
    else {
        duration[0] = parseInt(duration[0])
        duration = duration[0]
    }
    return duration
}
router.post("/delivery", bodyParser.json(), async (req, res, next) => {
    try {
        var user_id = req.body.user_id
        var location = []
        var from = []
        var to = []
        var user_location
        var captains_location = []
        var dur = 0, dis = 0, rate = 0
        const key = "AIzaSyA7nfzqox7HP_crX14tFzVLVpW3r5PnHoI";
        var sql = "SELECT * FROM `carts` where `user_id`=?";
        connection.query(sql, user_id, function (err, carts) {
            if (err) throw err
            user_location = carts[0].user_location
            for (var i = 0; i < carts.length; i++) {
                location.push(carts[i].prudect_location)
            }
            var uniq = [...new Set(location)];
            var sql = "SELECT * FROM `captain` where `online_status`=1 and `translation_status`=0";
            connection.query(sql, async (err, result) => {
                if (err) throw err
                if (result.length > 0) {
                    for (var i = 0; i < result.length; i++) {
                        captains_location.push(result[i].location)
                    }
                    const { data } = await axios.get(distance_api(uniq[0], key, captains_location))
                    for (var i = 0; i < uniq.length - 1; i++) {
                        if (i == 0) {
                            dis += await distance(captains_location[get_index(data)], uniq[i], key)
                            dur += await duration(captains_location[get_index(data)], uniq[i], key)
                            from.push(captains_location[get_index(data)])
                            to.push(uniq[i])
                            dis += await distance(uniq[i], uniq[i + 1], key)
                            dur += await duration(uniq[i], uniq[i + 1], key)
                            from.push(uniq[i])
                            to.push(uniq[i + 1])
                        }
                        else {

                            dis += await distance(uniq[i], uniq[i + 1], key)
                            dur += await duration(uniq[i], uniq[i + 1], key)
                            from.push(uniq[i])
                            to.push(uniq[i + 1])
                        }
                    }
                    dis += await distance(user_location, uniq[uniq.length - 1], key)
                    dur += await duration(user_location, uniq[uniq.length - 1], key)
                    from.push(uniq[uniq.length - 1])
                    to.push(user_location)
                    console.log(from)
                    console.log(to)
                    for (var i = 0; i < from.length; i++) {
                        if (i == from.length - 1) {
                            var sql = "INSERT INTO `captain_delivery`(`delivery_id`, `place_name`, `from_location`, `to_location`) VALUES ('"
                                + result[get_index(data)].delvary_id + "','user loaction','" +
                                from[i] + "','" + to[i] + "')";
                            connection.query(sql, function (err, result) {
                                if (err) throw err
                            })
                        }
                        else {
                            var sql = "INSERT INTO `captain_delivery`(`delivery_id`, `place_name`, `from_location`, `to_location`) VALUES ('"
                                + result[get_index(data)].delvary_id + "','" + carts[i].place_name + "','" +
                                from[i] + "','" + to[i] + "')";
                            connection.query(sql, function (err, result) {
                                if (err) throw err
                            })
                        }
                    }
                    for (var i = 0; i < carts.length; i++) {
                        var sql = "INSERT INTO `captain_delivery_menu`(`delivery_id`, `place_name`, `product_name`, `qty`, `total`) VALUES ('"
                            + result[get_index(data)].delvary_id + "','" + carts[i].place_name + "','" +
                            carts[i].product_name + "','" + carts[i].qty + "','" + carts[i].total + "')";
                        connection.query(sql, function (err, result) {
                            if (err) throw err
                        })
                    }
                    var sql = "SELECT * FROM `rate` where `captain_id`=?";
                    connection.query(sql, result[get_index(data)].delvary_id, function (err, r) {
                        for (var i = 0; i < r.length; i++) {
                            rate = rate + r[i].rate
                        }
                        rate /= r.length
                        var salary = (dis * 6.5).toFixed(4)
                        dis = ((dis).toFixed(4)).toString() + " mi"
                        dur = (dur).toString() + " mins"
                        if (err) throw err
                        res.status(200).json({
                            "delvary_id": result[get_index(data)].delvary_id,
                            "frist_name": result[get_index(data)].First_name,
                            "last_name": result[get_index(data)].last_name,
                            "Scooter": result[get_index(data)].Scooter,
                            "location": result[get_index(data)].location,
                            "Email": result[get_index(data)].Email,
                            "distance": dis,
                            "duration": dur,
                            "salary": salary,
                            "rate": rate
                        })
                    })
                }
                else {
                    res.status(400).json({
                        record: "no captain active"
                    })
                }
            })
        })
    }
    catch (err) {
        console.log(err)
        next(err)
    }
})
// {
//     "user_location": "Mohammed El-Sayed, Al Khosous, Al Khankah, Al Qalyubia Governorate",
//     "places": [
//         "Amin Yousry, Al Khosous, El Marg, Cairo Governorate",
//         "52-4 El-Salam, Al Khosous, Al Khankah, Al Qalyubia Governorate",
//         "22-4 Fahmy Abd El-Aziz, Al Khosous, Al Khankah, Al Qalyubia Governorate"
//     ]
// }

